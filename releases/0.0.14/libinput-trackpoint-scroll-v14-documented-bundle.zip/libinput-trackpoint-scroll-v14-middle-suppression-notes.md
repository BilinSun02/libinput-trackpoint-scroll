# libinput 1.31.0 TrackPoint scroll patch v14

## Base revision

This is a complete replacement patch against pristine libinput commit:

```text
659967488e1e66d7fb7210c6b86860c8e1e5bed4
```

Apply it directly to that commit, not on top of v13.1, v13, v12, or any earlier project patch.

## What changed from v13.1

The startup-coalescing, grid, profile, and mode-switch behavior is unchanged.
This revision adds a configurable no-scroll middle-click suppressor. The default
is enabled because the middle button is dedicated to scrolling in this setup.

Current startup and click-policy keys:

```ini
suppress_middle_click=true
first_step_distance=0.4
first_step_axis_merge_ms=70.0
first_step_max_reports=-1
idle_reset_ms=333.3
```


## Middle-click suppression

```ini
suppress_middle_click=true
```

TrackPoint on-button scrolling already defers an ordinary button event until
release, because movement may convert the gesture into scrolling. When the
button is released in `BUTTONSCROLL_BUTTON_DOWN` or `BUTTONSCROLL_READY`, v14
checks this setting before emitting the deferred press/release pair.

With the default `true` value:

```text
middle press + no scrolling + release -> no public button event
middle press + scrolling + release    -> ordinary scroll stop behavior
```

No middle-button press is emitted early and then withdrawn later. The setting
therefore cannot leave applications with an unmatched press. It affects only
the ordinary no-scroll fallback for the configured physical middle scroll
button on the custom TrackPoint path; it does not disable raw motion, startup
coalescing, sustained scrolling, Shift mode switching, or Scroll Lock. Set it
to `false` to restore upstream fallback behavior.

## Componentwise fixed startup step

After a new middle-button gesture, or after a raw-report gap greater than
`idle_reset_ms`, the first accepted report starts a fixed step. For each axis,
only the sign matters:

```text
positive component -> +first_step_distance
zero component     -> 0
negative component -> -first_step_distance
```

Examples with `first_step_distance=0.4`:

```text
( 1, 0) -> ( 0.4,  0.0)
( 0, 2) -> ( 0.0,  0.4)
( 1, 1) -> ( 0.4,  0.4)
( 7,-3) -> ( 0.4, -0.4)
```

The raw magnitude is deliberately ignored. The fixed output bypasses the
selected affine, quadratic, adaptive, or hyperbolic profile. It is queued for
the next 2 ms output tick, so no merge-window delay is introduced before the
first visible motion.

Startup reports are consumed rather than replayed into the profile path. Once
coalescing ends, the next raw report enters the ordinary interval-estimation,
2 ms reconstruction, and profile pipeline. Its interval is measured from the
immediately preceding raw report, including a preceding coalesced or ignored
rebound report.

## Axis coalescing

The merge window is measured from the first raw report, not from middle-button
press and not as a rolling deadline.

A previously unseen axis adds its signed fixed component. A same-sign component
on an already represented axis confirms that axis but adds no second fixed
step. Thus:

```text
t=0 ms   (1,0) -> queue (0.4,0)
t=6 ms   (0,1) -> queue (0,0.4)
                    cumulative fixed result: (0.4,0.4)
```

If both arrive before the next 2 ms timer tick, one `(0.4,0.4)` event may be
posted. Otherwise separate events are posted, but their cumulative displacement
is identical.

## Report-count limit

`first_step_max_reports` has the requested signed convention:

```text
N > 0   accept at most N initial reports
N = 1   only the first report is fixed; no cross-report coalescing
N = 0   disable fixed startup behavior; all reports use the normal profile path
N < 0   unlimited accepted reports within first_step_axis_merge_ms
```

An accepted same-sign repeat consumes one report slot even though it adds no
new fixed displacement. After the limit, surviving components use the ordinary
profile path, while opposite-sign rebound components remain suppressed until
the merge window expires. Thus `N=1` disables cross-report fixed-step
coalescing without disabling the short rebound guard.

## Rebound handling

Within the merge window, an opposite-sign component on an axis already present
in the fixed step is treated as mechanical rebound and ignored. It neither
cancels the remembered direction nor emits output. This remains true after the
coalescing report quota has been exhausted.

A report containing only such reversals does not consume the report-count
quota. This allows, for example:

```text
max reports = 2
( 1,0)   accepted as fixed X; count = 1
(-1,0)   rebound-only; ignored; count remains 1
( 0,1)   accepted as fixed Y; count = 2
result    (distance,distance)
```

For a mixed report such as `(-1,1)` after `(1,0)`, the X reversal is ignored
while the previously unseen positive Y component is accepted; the report then
counts once.

Opposite-sign reports outside the merge window are not treated as rebound and
are processed normally by the selected profile.

## Idle reset

`idle_reset_ms` is now compiled to a 333.3 ms default. A gap strictly greater
than the configured value resets interval history, restarts the dedicated
adaptive filter, and rearms startup coalescing. A value of zero makes every
positive raw-report gap a new burst.

## Profiles and defaults

The profile terminology and calibrated profile defaults remain unchanged:

```text
affine      k=0.4, b=0
quadratic   a=0.16, h=0, k=0.025
adaptive    velocity_scale=100, sensitivity=1.086, speed=0
hyperbolic  a=0.75, u=1.6, k=-1.175
```

`clamp_negative_output` applies only to profile output. The componentwise fixed
startup step always follows the raw component signs.

## Apply and build

```bash
git checkout --detach 659967488e1e66d7fb7210c6b86860c8e1e5bed4
git status --short
git apply --check /path/to/libinput-1.31.0-trackpoint-scroll-2ms-grid-startup-coalescing-middle-suppression-v14.patch
git apply /path/to/libinput-1.31.0-trackpoint-scroll-2ms-grid-startup-coalescing-middle-suppression-v14.patch
meson setup builddir --prefix=/usr/local -Dlibwacom=false
ninja -C builddir
sudo ninja -C builddir install
sudo ldconfig
```

Restart the Wayland session after installation. The configuration is read once
per TrackPoint device initialization, so replug a removable device or restart
the session after configuration changes.

## Validation scope

The delivered patch was checked for unified-diff parsing, old-side context
consistency with v13.1, application to the reconstructed pristine hunk preimage,
and post-application whitespace errors. A standalone compiled state-machine
test covers report limits 0, 1, 2, and negative; magnitude erasure; orthogonal
coalescing; same-sign repeats; rebound-only reports; mixed rebound/new-axis
reports; merge-window expiry; and idle rearming.

A small compiled branch model checked that suppression affects only the no-scroll middle-button fallback, that `false` restores the original press/release pair, and that non-middle buttons remain unaffected.

The actual Meson build in a complete pristine checkout remains the definitive
integration test.


## Current tested startup defaults retained in v14

```ini
first_step_axis_merge_ms=70.0
first_step_max_reports=-1
idle_reset_ms=333.3
```

The 70 ms merge window was the observed sweet spot for combining early
serialized axis reports. The negative report limit uses the documented
infinity convention, so the time window—not a report count—terminates
coalescing. The 333.3 ms idle threshold safely rearms the startup step sooner
than the earlier 500 ms default.

## Why the build command disables libwacom

The pinned source declares Meson's `libwacom` option as a boolean defaulting to
`true`; it is used for tablet identification. This TrackPoint project does not
need that functionality. A reported Ubuntu/Kubuntu build encountered an
otherwise unnecessary libwacom dependency until the option was disabled.
Accordingly, the documented setup uses `-Dlibwacom=false`. Users who require
libwacom-backed tablet identification should instead install the dependency and
enable it deliberately.
