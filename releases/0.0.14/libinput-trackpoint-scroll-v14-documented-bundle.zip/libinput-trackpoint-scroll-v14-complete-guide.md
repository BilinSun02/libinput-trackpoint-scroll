# TrackPoint button scrolling on GNOME/Wayland with patched libinput 1.31.0

**Project version:** v14 startup coalescing with middle-click suppression  
**Document date:** 2026-07-24  
**Target libinput revision:** `659967488e1e66d7fb7210c6b86860c8e1e5bed4` (`libinput 1.31.0`)  
**Primary patch:** `libinput-1.31.0-trackpoint-scroll-2ms-grid-startup-coalescing-middle-suppression-v14.patch`  
**Runtime configuration:** `/etc/libinput/trackpoint-scroll.conf`

This document is a self-contained installation, configuration, architecture, and maintenance guide for the custom TrackPoint button-scroll implementation developed for a ThinkPad TrackPoint module connected through a PS/2-to-USB adapter and used under GNOME on Wayland.

The patch is intentionally pinned to one exact libinput commit. It is not a generic patch that should be applied to arbitrary libinput releases.

---

## 1. What the patch does

The patch changes TrackPoint on-button scrolling while leaving ordinary pointer
motion under the normal libinput/GNOME cursor configuration.

The principal data path has two deliberately separate startup and sustained
branches:

```text
first qualifying sparse reports after a gesture or idle reset
    -> componentwise sign-only fixed startup step
    -> short axis-coalescing/rebound window
    -> continuous scroll events

all later sparse, irregular TrackPoint REL_X/REL_Y reports
    -> causal partition onto a uniform 2 ms grid
    -> dedicated scroll transfer function
    -> either unrestricted 2-D output or libinput axis locking
    -> continuous scroll events
```

The important properties are:

- Cursor acceleration and scroll acceleration are independent.
- The initial micro-scroll is profile-independent and predictable per axis.
- Startup magnitude is ignored: every represented nonzero axis receives exactly
  `first_step_distance` with the raw sign.
- Split-axis startup reports can coalesce without delaying the first visible
  output; opposite-sign rebound components are ignored during the merge window.
- Sparse sustained reports are regularized **before** nonlinear acceleration.
- Sustained output is generated on a 2 ms timer grid.
- There is no long velocity low-pass filter, position predictor, or momentum
  model.
- Four configurable sustained-scroll profiles are available:
  - `affine`
  - `quadratic`
  - `adaptive`
  - `hyperbolic`
- Negative-output clamping is a runtime config option for profile output.
- No-scroll middle-button clicks are suppressed by default without affecting scrolling.
- Ordinary scrolling is immediate free two-dimensional scrolling by default.
- Pressing Shift after the middle button toggles the current gesture between
  free and axis-locked modes.
- Scroll Lock toggles the default mode for subsequent gestures.
- Scroll Lock remains visible to normal software and keyboard LEDs.

The patch reduces libinput's ordinary 200 ms button-scroll activation timeout
to 1 ms.

### Current recommended configuration

```ini
profile=hyperbolic
clamp_negative_output=false
suppress_middle_click=true

first_step_distance=0.4
first_step_axis_merge_ms=70.0
first_step_max_reports=-1
idle_reset_ms=333.3

hyperbolic_a=0.75
hyperbolic_u=1.6
hyperbolic_k=-1.175
```

Firefox requires separate application-level scaling on the tested system; a
value around 50% currently feels closest to GNOME Papers. This is discussed
later.

## 2. Files and checksums

The v14 distribution consists of:

```text
libinput-1.31.0-trackpoint-scroll-2ms-grid-startup-coalescing-middle-suppression-v14.patch
trackpoint-scroll-v14.conf.example
libinput-trackpoint-scroll-v14-middle-suppression-notes.md
libinput-trackpoint-scroll-v14-complete-guide.md
libinput-trackpoint-scroll-v14-SHA256SUMS
```

Known SHA-256 values are listed in
`libinput-trackpoint-scroll-v14-SHA256SUMS`. Verify copied files with:

```bash
sha256sum -c libinput-trackpoint-scroll-v14-SHA256SUMS
```

V14 is a complete replacement patch. Apply it to the pristine pinned commit;
do not apply an earlier project patch first.

## 3. Hardware identity used in this project

The tested pointing device is a real ThinkPad TrackPoint module connected through a DIY keyboard/PS/2-to-USB conversion layer.

Observed input identity:

```text
Input device name:
  xy_3dg12 xy_3dg12 USB RF Adapter

Input device ID:
  bus     0x0003
  vendor  0x5859
  product 0x0001
  version 0x0110
```

Relevant capabilities include:

```text
REL_X
REL_Y
BTN_LEFT
BTN_RIGHT
BTN_MIDDLE
```

At low force, the device often emits one-unit reports separated by tens or hundreds of milliseconds. Earlier measurements found:

- a median interval around 129 ms in one low-force trace;
- common gaps around 50–200 ms;
- some ordinary gaps around 440 ms;
- high-force report intervals approaching about 10 ms.

This sparse behavior is the reason the patch regularizes raw displacement onto a fixed time grid.

---

# Part I: Setup from scratch

## 4. Install build prerequisites

On Ubuntu, install the basic toolchain and libinput build dependencies:

```bash
sudo apt update
sudo apt install git meson ninja-build build-essential pkg-config
sudo apt build-dep libinput
```

`apt build-dep` requires source repositories to be enabled. If it reports that no source repositories are configured, either enable `deb-src` entries or install the missing packages reported by Meson one by one.

The patch itself adds no new external library dependency. It uses libc parsing/math functions and existing libinput filter/timer infrastructure.

---

## 5. Clone and pin the exact source revision

Use the upstream repository:

```bash
git clone https://gitlab.freedesktop.org/libinput/libinput.git
cd libinput
```

Check out the exact pinned commit in detached-HEAD mode:

```bash
git checkout --detach 659967488e1e66d7fb7210c6b86860c8e1e5bed4
```

Verify it:

```bash
git rev-parse HEAD
git status --short
```

Expected commit:

```text
659967488e1e66d7fb7210c6b86860c8e1e5bed4
```

`git status --short` should print nothing before the patch is applied.

A worktree is convenient when retaining an unmodified clone:

```bash
cd /path/to/libinput-repository
git worktree add ../libinput-trackpoint-v14 \
  659967488e1e66d7fb7210c6b86860c8e1e5bed4
cd ../libinput-trackpoint-v14
```

---

## 6. Apply the patch

First check without modifying the tree:

```bash
git apply --check \
  /path/to/libinput-1.31.0-trackpoint-scroll-2ms-grid-startup-coalescing-middle-suppression-v14.patch
```

Then apply it:

```bash
git apply \
  /path/to/libinput-1.31.0-trackpoint-scroll-2ms-grid-startup-coalescing-middle-suppression-v14.patch
```

Run whitespace and scope checks:

```bash
git diff --check
git diff --stat
```

Expected changed source files:

```text
src/evdev-fallback.c
src/evdev.c
src/evdev.h
```

The current patch statistics are approximately:

```text
3 files changed, 921 insertions(+), 17 deletions(-)
```

Do not apply the patch on top of an earlier TrackPoint-scroll patch. If a disposable tree is contaminated, return it to the pinned commit:

```bash
git reset --hard 659967488e1e66d7fb7210c6b86860c8e1e5bed4
```

That command destroys uncommitted changes; use it only in a tree where that is acceptable.

---

## 7. Configure and build

Use this default build configuration:

```bash
meson setup builddir \
  --prefix=/usr/local \
  --buildtype=release \
  -Dlibwacom=false \
  -Dtests=false \
  -Ddebug-gui=false \
  -Ddocumentation=false
```

The pinned libinput source defines Meson's `libwacom` option as enabled by
default and uses it for tablet identification. This TrackPoint-only project does
not need that functionality. Explicitly disabling it avoids making an otherwise
irrelevant libwacom development dependency part of the build. A user report on
the original middle-scroll investigation specifically encountered this build
failure and resolved it by disabling libwacom. Users who need libwacom-backed
tablet identification should install the dependency and enable the option
deliberately.

The option is `-Dtests=false` (plural) in the pinned source.

Build:

```bash
ninja -C builddir
```

When rebuilding after source-only changes, rerun just:

```bash
ninja -C builddir
```

Meson reconfiguration is normally unnecessary unless build options or
dependencies change.

### Authoritative validation

The definitive integration tests are performed in the real pinned tree:

```bash
git apply --check /path/to/the-v14.patch
ninja -C builddir
```

Earlier development exposed two reasons not to trust synthetic patch validation
alone:

1. A generated v10 patch accidentally retained an impossible old-context
   `else` line in an `src/evdev.c` hunk. A synthetic preimage reproduced the
   same error and falsely accepted it.
2. An earlier helper named `normalized_length` collided with an existing
   libinput helper that used a different signature. Only a real compile exposed
   that namespace collision.

Always treat the real checkout and full compiler as authoritative.

## 8. Install the rebuilt libinput

Install to `/usr/local`:

```bash
sudo ninja -C builddir install
sudo ldconfig
```

Using `/usr/local` avoids directly overwriting distribution-owned files in `/usr`. The dynamic linker must nevertheless choose the newly installed `libinput.so.10` for the patch to affect GNOME and standalone tools.

Inspect the available libraries:

```bash
ldconfig -p | grep 'libinput\.so'
```

Inspect the command-line tool's linkage:

```bash
which libinput
readlink -f "$(command -v libinput)"
libinput --version
ldd "$(command -v libinput)" | grep libinput
```

On a running GNOME Wayland session, the already-running `gnome-shell`/Mutter process continues using the library it loaded at login. After installing a rebuilt library, **log out and log back in**. A reboot also works but is not normally necessary.

After logging back in, this can show the library mapped by GNOME Shell:

```bash
grep -F libinput "/proc/$(pgrep -n gnome-shell)/maps" | sort -u
```

If `/usr/lib/.../libinput.so.10` is still selected instead of `/usr/local/...`, inspect `/etc/ld.so.conf`, `/etc/ld.so.conf.d/`, and the `ldconfig -p` ordering.

### Test the build tree before installation when debugging

When diagnosing routing or library-selection problems, prefer the executable built inside `builddir`. Its build RPATH reduces ambiguity about which shared object it loads.

Find it:

```bash
find builddir -type f -name libinput -perm -111 -print
```

Then inspect linkage:

```bash
BUILD_LIBINPUT=/absolute/path/from/the-command
"$BUILD_LIBINPUT" --version
ldd "$BUILD_LIBINPUT" | grep libinput
```

---

## 9. Install the runtime scroll configuration

Install the example file:

```bash
sudo install -D -m 0644 \
  /path/to/trackpoint-scroll-v14.conf.example \
  /etc/libinput/trackpoint-scroll.conf
```

Edit it with:

```bash
sudoedit /etc/libinput/trackpoint-scroll.conf
```

The tested starting point is already in the example:

```ini
profile=hyperbolic
clamp_negative_output=false
suppress_middle_click=true

first_step_distance=0.4
first_step_axis_merge_ms=70.0
first_step_max_reports=-1
idle_reset_ms=333.3

hyperbolic_a=0.75
hyperbolic_u=1.6
hyperbolic_k=-1.175
```

The file is read once when each TrackPoint device is initialized.

After **config-only** changes:

- unplug and reconnect a removable TrackPoint/adapter; or
- log out and back in for a built-in/non-removable device.

After installing a rebuilt library, log out and back in so Mutter loads the new
shared object. `udevadm trigger` alone is not a reliable way to reload the
libinput device object owned by the existing compositor process.

# Part II: Make the adapter a TrackPoint

## 10. Why the udev classification is necessary

The custom grid path activates only when both conditions are true:

```text
device has EVDEV_TAG_TRACKPOINT
scroll method is LIBINPUT_CONFIG_SCROLL_ON_BUTTON_DOWN
```

The first condition ultimately depends on udev's input-device classification. A generic USB relative pointer may initially have:

```text
ID_INPUT_MOUSE=1
```

but not:

```text
ID_INPUT_POINTINGSTICK=1
```

The pointing-stick tag is an additional specialization. It is normal and desirable to retain both:

```text
ID_INPUT_MOUSE=1
ID_INPUT_POINTINGSTICK=1
```

Do not unset `ID_INPUT_MOUSE`.

---

## 11. Find the correct event node

Use either:

```bash
sudo libinput list-devices
```

or:

```bash
for f in /sys/class/input/event*/device/name; do
    printf '%s: ' "${f%/device/name}"
    cat "$f"
done
```

After identifying `/dev/input/eventN`, inspect its current properties:

```bash
udevadm info --query=property --name=/dev/input/eventN |
  grep -E '^(ID_BUS|ID_VENDOR_ID|ID_MODEL_ID|ID_INPUT_)='
```

For unusual composite adapters, the event node may not carry `ID_BUS`, `ID_VENDOR_ID`, or `ID_MODEL_ID`. In that case inspect the sysfs hierarchy:

```bash
udevadm info --attribute-walk --name=/dev/input/eventN
```

---

## 12. The precise udev rule used for this device

This USB receiver exposes multiple interfaces. A rule that matches only USB vendor/product IDs can accidentally classify several event nodes from the receiver as pointing sticks.

The known precise rule matches attributes on the same **input-device parent**:

```udev
ACTION!="remove", \
SUBSYSTEM=="input", \
KERNEL=="event[0-9]*", \
ATTRS{name}=="xy_3dg12 xy_3dg12 USB RF Adapter", \
ATTRS{id/vendor}=="5859", \
ATTRS{id/product}=="0001", \
ENV{ID_INPUT_POINTINGSTICK}="1"
```

Save it as:

```text
/etc/udev/rules.d/99-xy-3dg12-pointing-stick.rules
```

For example:

```bash
sudoedit /etc/udev/rules.d/99-xy-3dg12-pointing-stick.rules
```

### Important udev parent-matching rule

All `ATTRS{...}` conditions in one udev rule must be satisfied by the same parent device.

Do **not** combine:

```text
ATTRS{name}
```

from the input parent with:

```text
ATTRS{idVendor}
ATTRS{idProduct}
```

from the USB parent in the same rule. That apparently reasonable rule cannot match because the attributes belong to different ancestors.

The chosen rule uses:

```text
ATTRS{name}
ATTRS{id/vendor}
ATTRS{id/product}
```

which all occur on the same input parent.

Note the capitalization and slash distinction:

```text
USB parent:    idVendor, idProduct
input parent:  id/vendor, id/product
```

---

## 13. Test and activate the udev rule

Test against the current event node:

```bash
sudo udevadm test /sys/class/input/eventN 2>&1 |
  grep -E 'POINTINGSTICK|99-xy-3dg12-pointing-stick'
```

Reload rules:

```bash
sudo udevadm control --reload-rules
```

Then physically unplug and reconnect the device. If GNOME was running while the device was previously misclassified, logging out before reconnecting is the cleanest reset.

Verify:

```bash
udevadm info --query=property --name=/dev/input/eventN |
  grep -E '^ID_INPUT_(MOUSE|POINTINGSTICK)='
```

Expected:

```text
ID_INPUT_MOUSE=1
ID_INPUT_POINTINGSTICK=1
```

Also inspect:

```bash
sudo libinput list-devices | sed -n '/TrackPoint/,/^$/p'
```

The exact displayed device title can vary, so a broader search may be necessary:

```bash
sudo libinput list-devices | grep -n -A30 -B3 'xy_3dg12'
```

Correct classification can change the cursor feel because GNOME now applies the **pointing-stick** settings rather than the **mouse** settings. This is expected and is addressed below.

---

# Part III: User-visible controls

## 14. Gesture modes

The patch provides two routing modes.

### Free mode

```text
accelerated 2-D delta
    -> direct continuous-axis notifier
```

Characteristics:

- immediate unrestricted two-dimensional output;
- no generic button-scroll buildup threshold;
- no axis locking;
- diagonal scrolling remains diagonal.

### Locked mode

```text
accelerated 2-D delta
    -> evdev_post_scroll()
    -> ordinary libinput buildup and direction/axis locking
```

This retains libinput's standard locked-axis behavior.

### Startup default

At process/session startup, Scroll Lock's custom toggle is off:

```text
middle + movement          -> free mode
middle, then Shift         -> locked mode
```

After one fresh Scroll Lock press:

```text
middle + movement          -> locked mode
middle, then Shift         -> free mode
```

Scroll Lock toggles the process-wide default for later gestures. The default is latched when the middle button is pressed; pressing Scroll Lock during an existing gesture does not retroactively change that gesture.

### Shift ordering

Shift is deliberately order-sensitive:

- Shift held **before** middle remains visible to applications and does not invoke the custom mode switch.
- Shift pressed **after** middle switches the current gesture and is consumed.
- The matching release of a consumed Shift is also consumed.
- Repeated events for an already consumed Shift remain consumed without repeatedly toggling the mode.

Pressing Shift during the short click-versus-scroll timeout immediately advances the button-scroll state to `READY`, so the user does not need to wait for the timer before selecting the alternate mode.

### Scroll Lock visibility

Scroll Lock press/release events are not consumed. The patch observes a fresh physical press, toggles its internal default, then allows the normal keyboard event path to continue. Desktop software can therefore continue to track Scroll Lock and update an LED.

---

## 15. Middle-click suppression

The physical middle button remains the configured button-scroll trigger. The
ordinary libinput state machine therefore still delays any public button event
while it determines whether the gesture becomes scrolling.

The runtime key is:

```ini
suppress_middle_click=true
```

With the default `true` value, releasing the button in
`BUTTONSCROLL_BUTTON_DOWN` or `BUTTONSCROLL_READY` discards the deferred
middle-button click instead of emitting a press/release pair. Once movement has
changed the state to `BUTTONSCROLL_SCROLLING`, release follows the ordinary
scroll-stop path.

```text
middle press + no accepted scroll motion + release -> no public button event
middle press + scrolling motion + release          -> scroll stop, no click
```

This is implemented below the compositor and applications, so it also covers
Wayland clients that ignore GNOME's middle-click-paste preference. It does not
disable the physical button as the scrolling trigger, does not alter startup
coalescing or acceleration, and does not consume unrelated mouse buttons. No
press is emitted early and then retracted, so applications cannot receive an
unmatched middle-button press.

Set `suppress_middle_click=false` to restore libinput's ordinary no-scroll
middle-click fallback. The setting applies to the configured physical middle
scroll button on the custom TrackPoint on-button-scroll path.

---

# Part IV: Scroll configuration reference

## 16. Configuration file syntax

Path:

```text
/etc/libinput/trackpoint-scroll.conf
```

The parser accepts simple `key=value` lines.

- Leading and trailing whitespace is removed.
- `#` begins an inline comment.
- Empty lines are ignored.
- Lines whose first non-space character is `;` are ignored.
- Lines whose first non-space character is `[` are ignored, allowing visually
  sectioned example files, but there is no actual INI section semantics.
- Names and values are case-sensitive.
- Unknown keys, malformed numbers, nonfinite numbers, and invalid booleans are
  logged and ignored.
- `suppress_middle_click` and `clamp_negative_output` use the boolean syntax below.
- `first_step_distance`, `first_step_axis_merge_ms`, and `idle_reset_ms` must be
  finite and nonnegative.
- `first_step_max_reports` is a signed integer: positive values bound the number
  of accepted reports, zero disables the fixed startup step, and negative values
  mean unlimited reports within the merge-time window.
- The internal line buffer is 256 bytes, so keep each setting line short.

Boolean values accepted for `true`:

```text
true
yes
on
1
```

Boolean values accepted for `false`:

```text
false
no
off
0
```

The file is global to the libinput process. Every TrackPoint initialized by
that process reads the same file, although each device stores its own resulting
parameters and adaptive-filter state.

## 17. Common vector model

For a memoryless profile, let the current reconstructed two-dimensional 2 ms sample be:

```text
v = (vx, vy)
```

and its magnitude be:

```text
x = hypot(vx, vy)
```

The selected profile calculates a scalar output magnitude `y`.

For `x > 0`, the patch emits:

```text
out = (y / x) * v
```

This preserves the input direction and makes the profiles rotationally symmetric.

At exactly `x = 0`, no output is emitted because no direction exists. A positive offset can nevertheless create an intentional discontinuity:

```text
output at x = 0       -> exactly zero
limit as x approaches 0 from above -> configured positive offset
```

If `y` is negative and clamping is disabled, `y/x` is negative and the output direction reverses.

---

## 18. Affine profile

Canonical name:

```ini
profile=affine
```

Formula:

```text
y = affine_k * x + affine_b
```

Defaults:

```ini
affine_k=0.4
affine_b=0.0
```

These give exactly `y=1` at `x=2.5`.

The zero intercept is deliberate. A positive affine intercept creates the same
fixed onset jump at every very small nonzero force and, on the tested hardware,
tends to overshoot when making the lightest possible adjustment. The slope
`0.4` already provides visible low-force movement without that jump.

A nonzero `affine_b` is still accepted and intentionally creates an onset jump.
Negative slope or intercept values are also applied literally.

Compatibility aliases:

```text
profile: linear, flat
keys:    linear_k, flat_k, linear_b, flat_b
```

---

## 19. Quadratic profile

Canonical name:

```ini
profile=quadratic
```

Formula:

```text
y = quadratic_a * (x - quadratic_h)^2 + quadratic_k
```

Defaults:

```ini
quadratic_a=0.16
quadratic_h=0.0
quadratic_k=0.025
```

These give `y=1.025` at `x=2.5`.

The small positive constant is deliberate. With a pure quadratic passing
through the origin, the output remains extremely small until force has moved a
noticeable distance away from zero. The offset makes the lightest nonzero
movement visible. Parameters are applied literally: the implementation does
not force the vertex to the origin and does not impose monotonicity.

---

## 20. Adaptive profile

Canonical name:

```ini
profile=adaptive
```

The adaptive profile is stateful. It owns a dedicated instance of libinput's
upstream TrackPoint adaptive pointer filter and its velocity tracker. It does
**not** share history with the cursor's pointer filter.

Pipeline:

```text
scaled   = v / adaptive_velocity_scale
filtered = upstream TrackPoint adaptive filter(scaled, adaptive_speed)
out      = filtered * adaptive_velocity_scale * adaptive_sensitivity
```

Defaults:

```ini
adaptive_velocity_scale=100.0
adaptive_sensitivity=1.086
adaptive_speed=0.0
```

For steady 2 ms samples and libinput's default TrackPoint multiplier `M=1`,
these values give approximately `y=1` at `x=2.5`. The tracker sees
`2.5 / (100 * 2 ms) = 0.0125` units/ms. At speed setting zero, the upstream
factor is approximately `0.368327542`, so:

```text
2.5 * 0.368327542 * 1.086 = 1.000009...
```

A device-specific `AttrTrackpointMultiplier` other than 1 changes both tracked
velocity and output scale, so the exact equality is then no longer expected.

`adaptive_velocity_scale` horizontally shifts where the adaptive curve is
sampled. `adaptive_sensitivity` scales final output. `adaptive_speed` is passed
to the upstream filter and is normally in `[-1, 1]`.

The dedicated filter is restarted at a new gesture/burst, an idle reset, and a
free/locked mode switch. This prevents stale velocity history crossing those
boundaries.

Upstream libinput's ordinary TrackPoint continuous button-scroll branch uses
constant scaling. This project deliberately invokes the regular adaptive
dispatch of a separate filter so that this profile is genuinely
velocity-dependent and remains independent of GNOME's cursor profile.

---

## 21. Hyperbolic profile

Canonical name:

```ini
profile=hyperbolic
```

Formula:

```text
y = hyperbolic_a * sqrt(hyperbolic_u^2 + x^2) + hyperbolic_k
```

Defaults and current tested values:

```ini
hyperbolic_a=0.75
hyperbolic_u=1.6
hyperbolic_k=-1.175
```

They give approximately `y=1.0511` at `x=2.5`.

For nonzero `u`, the curve changes approximately quadratically near zero and
approaches a line of slope `hyperbolic_a` at high input. With the defaults:

```text
limit x -> 0+ = 0.75 * 1.6 - 1.175 = 0.025
```

Thus the profile deliberately has a small positive onset jump, while exact
zero still emits zero because there is no direction to retain.

Compatibility aliases:

```text
profile: asymptotic, asymptotic-linear
keys:    asymptotic_a, asymptotic_u, asymptotic_k
```

---

## 22. Negative-output clamping

Runtime setting:

```ini
clamp_negative_output=false
```

Behavior:

```text
false -> preserve negative y, including direction reversal
true  -> replace negative y with zero
```

Clamping does not remove positive offsets or positive onset jumps.

For the adaptive profile, a negative `adaptive_sensitivity` reverses the adaptive output when clamping is disabled. When clamping is enabled, a negative adaptive sensitivity produces zero output.

---

# Part V: GNOME cursor configuration

## 23. Cursor and scroll settings are deliberately separate

V14's custom profile controls TrackPoint **scrolling** only.

GNOME's pointing-stick GSettings continue to control ordinary **cursor movement**:

```text
org.gnome.desktop.peripherals.pointingstick
```

Inspect them:

```bash
gsettings list-recursively org.gnome.desktop.peripherals.pointingstick
```

Important keys:

```bash
gsettings get org.gnome.desktop.peripherals.pointingstick accel-profile
gsettings get org.gnome.desktop.peripherals.pointingstick speed
```

On the tested setup, a flat cursor profile and speed around `0.5` felt correct:

```bash
gsettings set org.gnome.desktop.peripherals.pointingstick accel-profile 'flat'
gsettings set org.gnome.desktop.peripherals.pointingstick speed 0.5
```

The speed range is normally `-1.0` through `1.0`.

The GNOME GUI pointing-stick acceleration toggle tracks the pointing-stick `accel-profile` key. Labels and exact stored value can vary by GNOME version; inspect the key directly after toggling.

These settings are category-wide for pointing sticks, not per physical device.

### Compare with mouse settings

Reclassification from mouse to pointing stick can make the cursor feel different because GNOME stops applying the mouse schema and starts applying the pointing-stick schema.

Inspect both:

```bash
gsettings get org.gnome.desktop.peripherals.mouse speed
gsettings get org.gnome.desktop.peripherals.mouse accel-profile

gsettings get org.gnome.desktop.peripherals.pointingstick speed
gsettings get org.gnome.desktop.peripherals.pointingstick accel-profile
```

### Inspect defaults and stored overrides

A memory GSettings backend shows the schema default without reading normal saved settings:

```bash
GSETTINGS_BACKEND=memory \
gsettings get org.gnome.desktop.peripherals.pointingstick speed

GSETTINGS_BACKEND=memory \
gsettings get org.gnome.desktop.peripherals.pointingstick accel-profile
```

Inspect whether a dconf override exists:

```bash
dconf read /org/gnome/desktop/peripherals/pointingstick/speed
dconf read /org/gnome/desktop/peripherals/pointingstick/accel-profile
```

No output means no user override is stored.

---

## 24. Do not infer GNOME's live profile from `libinput list-devices`

This was a major debugging trap.

```bash
sudo libinput list-devices
```

creates its own libinput context and reports libinput's built-in defaults. Its profile asterisk does **not** show the profile currently selected inside GNOME/Mutter.

Likewise:

```bash
sudo libinput debug-events
```

creates another independent libinput context. It does not inherit Mutter's live GSettings profile.

Consequences:

- The GNOME GUI can visibly change cursor movement while `libinput list-devices` output stays unchanged.
- Desktop behavior and `sudo libinput debug-events` can use different cursor profiles.
- Use `gsettings` to inspect GNOME's live preference.
- Use explicit `debug-events` options when testing a standalone libinput context.

For example:

```bash
sudo libinput debug-events \
  --device /dev/input/eventN \
  --set-profile=flat \
  --set-speed=0.5 \
  --set-scroll-method=button \
  --set-scroll-button=BTN_MIDDLE
```

Check `libinput debug-events --help` on the installed version if option names differ.

V14's dedicated scroll accelerator avoids the earlier architecture in which scroll tuning accidentally depended on the pointer profile selected in the current libinput context.

---

# Part VI: Firefox and application-level scaling

## 25. Firefox settings to recheck

Open:

```text
about:config
```

Inspect:

```text
mousewheel.default.delta_multiplier_x
mousewheel.default.delta_multiplier_y
mousewheel.default.delta_multiplier_z
```

Firefox's default is `100`, meaning 100%.

On the tested system, these values made Firefox feel much closer to Papers:

```text
mousewheel.default.delta_multiplier_x = 50
mousewheel.default.delta_multiplier_y = 50
```

The Z multiplier does not affect ordinary horizontal or vertical scrolling and can normally remain `100`, though the user previously changed all three and should simply recheck the saved values.

### Why one system-wide speed cannot normalize every application

Papers uses a normal GTK 4 `GtkScrolledWindow`; Papers itself adds no custom multiplier. The tested GTK 4 path receives Wayland surface-unit deltas and multiplies them by GTK's standard factor of 2.5 before adding them to the scroll adjustment.

Firefox uses GTK 3 on this path. GTK 3 first divides the raw Wayland continuous-axis value by 10. Firefox then multiplies the resulting smooth delta by 3 and represents it in **line units**. Gecko converts those line units into pixels using the target scroll frame's font metrics.

This means a rough Firefox-to-Papers match depends on page line height. For ordinary web content around 16–17 px, a Firefox multiplier around 50% is mathematically plausible. Pages with larger line metrics can make a lower value such as 33% feel closer.

Therefore:

- tune the libinput profile for a well-behaved native reference application such as Papers;
- treat Firefox's multiplier as an application-specific correction;
- do not expect one exact value to match every website or scroll container.

---

# Part VII: Intermediate implementation architecture

## 26. Source-file responsibilities in v14

V14 touches three files.

### `src/evdev-fallback.c`

Responsibilities:

- observes Scroll Lock and post-middle Shift keyboard events;
- selects the custom grid only for TrackPoint on-button scrolling;
- routes raw unaccelerated `REL_X/REL_Y` button-scroll motion into the custom
  startup/grid handler;
- leaves non-TrackPoint and non-button-scroll devices on the ordinary path.

The routing condition is essentially:

```c
(device->tags & EVDEV_TAG_TRACKPOINT) &&
(device->scroll.method == LIBINPUT_CONFIG_SCROLL_ON_BUTTON_DOWN)
```

### `src/evdev.c`

Responsibilities:

- runtime config parser, including startup controls, clamping, and profiles;
- componentwise fixed-step startup state machine;
- bounded-by-time axis coalescing and rebound suppression;
- dedicated accelerator initialization, dispatch, restart, and validation;
- Scroll Lock and consumed-Shift global state;
- 2 ms sustained-scroll interval estimator and ring buffer;
- timer callback;
- button press/release lifecycle;
- deferred no-scroll middle-click suppression;
- free versus locked posting;
- stop-event bookkeeping;
- 1 ms activation timeout.

### `src/evdev.h`

Responsibilities:

- profile enum;
- startup/profile/click-policy parameter structure;
- fixed-step signs, merge-window state, interval estimator, and removal-ring
  structures;
- state embedded in `struct evdev_device`;
- cross-file function declarations.

The final design does not modify `filter-trackpoint-flat.c`. The dedicated
scroll accelerator is no longer owned by whichever pointer profile happens to
be selected.

## 27. Device initialization and destruction

When a pointer device tagged as a TrackPoint is configured:

1. Default scroll-profile values are installed.
2. `/etc/libinput/trackpoint-scroll.conf` is parsed.
3. A dedicated upstream TrackPoint adaptive filter is allocated.
4. Its `adaptive_speed` is set and validated.
5. The device is rejected if the dedicated filter cannot be allocated.

The adaptive filter is allocated even when the selected runtime profile is memoryless. This keeps switching via config simple and gives the device a complete accelerator object.

At device destruction:

```text
pointer filter is destroyed
dedicated scroll adaptive filter is destroyed
scroll timer is destroyed
```

The explicit extra destruction is essential because the dedicated filter is not owned by `device->pointer.filter`.

---

## 28. Startup fixed step and the 2 ms causal boxcar grid

Current constants/defaults:

```text
grid period:                         2 ms
initial sustained interval estimate: 240 ms
interval history length:              5
minimum sustained interval:          10 ms
maximum sustained interval:         250 ms
first-step distance:                  0.4
first-step merge window:             70.0 ms
first-step report limit:             unlimited (-1)
idle reset/rearm threshold:          333.3 ms
ring size:                           128 slots
```

### Profile-independent startup step

After a new middle-button gesture, or after a raw-report gap strictly greater
than `idle_reset_ms`, the next qualifying report starts a fixed step. For each
axis, magnitude is discarded and only the sign is retained:

```text
positive component -> +first_step_distance
zero component     -> 0
negative component -> -first_step_distance
```

With the default distance 0.4:

```text
( 1, 0) -> ( 0.4,  0.0)
( 0, 2) -> ( 0.0,  0.4)
( 1, 1) -> ( 0.4,  0.4)
( 7,-3) -> ( 0.4, -0.4)
```

The fixed displacement bypasses affine, quadratic, adaptive, and hyperbolic
mapping. It is queued for the next 2 ms timer tick, so the implementation does
not wait until the merge window closes before providing visible feedback.

A consumed startup report is not replayed into the profile path. This avoids
double-counting and keeps the first micro-step independent of profile choice.
The timestamp is still retained so that the first later profile-governed report
uses the actual interval since the preceding hardware report.

### Axis coalescing

`first_step_axis_merge_ms` is measured from the first raw report as a fixed
window, not as a rolling deadline. During the tested 70 ms window, a previously
unseen axis may add its one signed fixed component:

```text
t=0 ms   (1,0) -> queue (0.4,0)
t=6 ms   (0,1) -> queue (0,0.4)
                    cumulative fixed result: (0.4,0.4)
```

If both components arrive before the next 2 ms tick, they may be posted in one
combined event. Otherwise they are posted separately, but cumulative output is
identical.

A same-sign repeat on an already represented axis adds no second fixed step.
`first_step_max_reports` controls how many accepted reports may participate:

```text
N > 0   accept at most N initial reports
N = 1   fix only the first report; do not coalesce later axes
N = 0   disable fixed startup behavior; use the normal profile path
N < 0   no report-count limit; the merge-time window is the only bound
```

The tested default is `-1`, so all qualifying reports inside the 70 ms window
may participate.

### Rebound suppression

Within the merge window, an opposite-sign component on an already represented
axis is treated as mechanical rubber rebound and ignored. It does not cancel
the remembered direction, emit a profile delta, or consume a report slot when
the whole report consists only of reversals.

For example:

```text
( 1,0)   -> fixed positive X
(-1,0)   -> ignored rebound
( 0,1)   -> fixed positive Y
result   -> (distance,distance)
```

For a mixed report such as `(-1,1)` after `(1,0)`, X is ignored as rebound while
Y may still add its fixed component. Outside the merge window, opposite signs
are ordinary input and enter the sustained profile path.

### Sustained interval estimate

For each profile-governed raw report, elapsed time since the previous raw report
is:

1. clamped to `[10, 250]` ms;
2. inserted into a five-entry circular history;
3. summarized using the median.

Before any measured sustained interval is available, 240 ms is used.

### Sustained report partition

For a raw displacement report `d` and estimated interval `T`:

```text
N = round(T / 2 ms)
share = d / N
```

`N` is clamped to at least 1 and at most 127. The share begins contributing on
the next timer tick and is scheduled for removal after `N` ticks. Overlapping
reports add linearly.

This creates a causal rectangular/boxcar contribution for each sustained
report:

```text
one raw displacement d
    -> N identical 2 ms unaccelerated shares
    -> sum of the N shares equals d
```

No already emitted share is revised later.

### Ring-buffer implementation

`evdev_scroll_grid` contains:

- `pending_delta`: sustained shares received since the previous tick;
- `active_delta`: sum of all currently live sustained shares;
- `pending_fixed_delta`: startup displacement waiting for the next tick;
- a 128-slot removal ring;
- `next_slot`: current expiration slot;
- `live_contributions`: number of live sustained-report contributions;
- startup signs, merge-window state, report count, and interval history;
- lifecycle flags.

When a sustained report arrives:

```text
pending_delta += share
removals[next_slot + N] += share
live_contributions += 1
```

On each tick, conceptually:

```text
active_delta -= removals[next_slot]
clear removal slot
active_delta += pending_delta
clear pending_delta
advance next_slot

output = pending_fixed_delta
clear pending_fixed_delta
if active_delta is nonzero:
    output += accelerate(active_delta)
```

The removal slot also stores a contribution count because multiple reports can
expire on the same tick. When `live_contributions` reaches zero,
`active_delta` is explicitly set to exact zero to eliminate floating-point
cancellation residue.

The timer continues while either fixed output is pending or sustained
contributions remain live.

### Why the boxcar is important

The sustained branch preserves raw displacement **before** the nonlinear
profile and avoids revisable prediction. It does not attempt to infer an exact
hidden continuous trajectory. It chooses a finite causal spreading tail
instead.

On physical middle-button release, any remaining tail is canceled immediately.
Thus prompt stopping is prioritized over emitting every remaining reconstructed
share after release.

## 29. Why resampling must precede acceleration

Nonlinear acceleration and temporal redistribution do not commute.

Wrong order:

```text
irregular raw packet
    -> nonlinear acceleration
    -> spread accelerated result
```

Correct order:

```text
irregular raw displacement
    -> distribute into uniform 2 ms samples
    -> apply transfer function to each sample
```

If acceleration is applied per hardware packet first, identical physical movement can produce different output merely because the hardware packetized it differently.

The fixed 2 ms period was selected instead of 8 ms because separate testing showed high-force report intervals near 10 ms. A 2 ms grid oversamples that cadence and is less likely to align with it pathologically.

---

## 30. Timer reuse and button-scroll state

The patch reuses `device->scroll.timer` for two phases:

1. the 1 ms click-versus-scroll activation timeout;
2. repeated 2 ms grid ticks while scrolling.

The timeout callback distinguishes these cases using button-scroll state and `grid->timer_active`.

This reuse avoids adding another libinput timer object but requires careful cancellation and state transitions on:

- press;
- first scrolling motion;
- Shift mode switch;
- release;
- idle reset.

The first timer firing while state is `BUTTONSCROLL_BUTTON_DOWN` changes it to `BUTTONSCROLL_READY` and returns. During `BUTTONSCROLL_SCROLLING`, a timer firing processes one grid tick and schedules the next tick if contributions remain.

On release from `BUTTONSCROLL_BUTTON_DOWN` or `BUTTONSCROLL_READY`, the code checks `suppress_middle_click`. When enabled and the configured scroll button is the physical middle button, the deferred press/release pair is discarded. This check occurs only after the scrolling decision, so the scroll state machine and timer behavior are unchanged.

---

## 31. Burst and idle reset behavior

If the time since the previous raw report is strictly greater than the
configured `idle_reset_ms`—333.3 ms by default—the grid begins a new burst:

- pending/live sustained boxcar state is reset;
- startup signs, report count, and merge-window state are reset;
- the fixed startup step is rearmed;
- the recent interval estimator is reset;
- the first sustained interval returns to 240 ms;
- the dedicated adaptive filter is restarted.

Within one middle-button gesture, the `posted` flag is preserved across an
internal burst reset. That allows release logic to know whether the public
scroll sequence has ever actually started and whether a stop event is
appropriate.

## 32. Public posting and the `posted` flag

Free mode calls the internal continuous-axis notifier directly. Locked mode calls `evdev_post_scroll()`, which may suppress initial values through ordinary buildup/direction logic.

The patch marks:

```text
grid.posted = true
```

inside the public continuous-axis notifier whenever the grid is active.

This records actual delivery at the final boundary rather than merely assuming that a nonzero internal delta was posted.

On release, a stop event is emitted only if:

- the grid was not used; or
- the grid was used and at least one public event was posted.

This avoids emitting a stop for a scroll sequence that never became visible.

The source retains libinput's existing misspelled internal function name:

```c
evdev_notify_axis_continous
```

Do not “correct” that spelling in only the new call sites without also changing the existing declaration/definition consistently.

---

## 33. Mode-switch reset semantics

When post-middle Shift toggles mode:

1. any active timer is canceled;
2. if output was already posted, a scroll-stop event ends the current sequence;
3. generic axis buildup/direction state is reset;
4. pending pre-Shift reconstruction is discarded;
5. the grid is restarted in the opposite mode;
6. the adaptive filter history is restarted.

Discarding pending pre-Shift shares is deliberate. Only movement after the mode switch contributes to the new sequence, avoiding delayed output from the old policy leaking into the new one.

---

## 34. Cross-device keyboard handling

The keyboard generating Shift or Scroll Lock need not be the same physical device as the TrackPoint.

V14 uses process-wide static state:

```text
trackpoint_scroll_shift_target
trackpoint_scroll_lock_by_default
consumed_shifts[16]
```

`trackpoint_scroll_shift_target` points to the currently active TrackPoint button-scroll target.

The consumed-Shift table is keyed by keyboard device pointer and key code. It has 16 slots, which is ample for ordinary simultaneous Shift events but is still a fixed internal limit.

Scroll Lock toggles only on a fresh physical press where the updated key count is exactly one. Auto-repeat or duplicate presses do not repeatedly toggle the mode.

The global design assumes that one TrackPoint gesture is the meaningful target at a time. Supporting multiple simultaneous TrackPoint scrolling gestures would require per-seat or per-gesture routing rather than one global target pointer.

---

# Part VIII: Important failed approaches and diagnostic lessons

## 35. Long smoothing and trajectory prediction

Several earlier approaches improved apparent smoothness but produced undesirable dynamics:

- long attack/release time constants;
- fixed rendering lag;
- bounded extrapolation;
- prediction decay;
- correction toward later reports;
- accumulated position error repayment.

These created:

- startup delay;
- momentum-like buildup;
- overshoot after release;
- reverse correction events;
- instability when later reports revised an already predicted trajectory.

The key lesson is:

> Do not emit motion from a mutable predicted target and later try to repay its error.

V14's boxcar shares are assigned once and never revised.

---

## 36. Hand-jitter and reverse-gating heuristics

Early reasoning overemphasized hand jitter and TrackPoint recalibration. That led to forced-stop thresholds, reverse-distance gates, rebound detection, and asymmetric smoothing.

The strongest evidence instead pointed to sparse packet timing as the main low-force problem.

V14 therefore does not include speculative hand-jitter suppression or reverse gating. Deliberate two-dimensional reversal is preserved naturally by the vector profile.

Hardware-specific rebound filtering should be reconsidered only if a controlled test demonstrates a repeatable residual problem after the current sparse-signal handling.

---

## 37. Direct notifier misdiagnosis versus final use

At one stage, sparse output was blamed entirely on `evdev_post_scroll()` buildup. A diagnostic patch bypassed it, but that alone did not solve the broader problem.

The conclusion was not that direct notification is always wrong. The final architecture uses it for a precise purpose:

- free mode intentionally bypasses generic buildup and axis locking;
- locked mode intentionally retains `evdev_post_scroll()`.

The earlier mistake was treating downstream buildup as the sole source of sparse timing rather than first proving the 2 ms reconstruction path.

---

## 38. Pointer-profile coupling and inert tuning constants

An earlier version stored custom scroll acceleration in `filter-trackpoint-flat.c` and dispatched grid ticks through:

```text
device->pointer.filter
```

This tied scrolling to the active cursor profile.

Consequences:

- custom constants were active only under the flat pointer filter;
- a standalone `debug-events` context could default to adaptive and bypass them;
- GNOME's live profile and the standalone tool's profile could differ;
- very large parameter changes appeared mysteriously inert.

V14 fixes the architecture rather than compensating with more tuning:

```text
GNOME cursor profile -> cursor only
V14 dedicated scroll accelerator -> scrolling only
```

---

## 39. Patch validation lessons

Two low-level failures are worth preserving as process rules.

### Malformed hunk accepted by synthetic preimage

V10's `src/evdev.c` hunk accidentally included a stray context line from a removed earlier hunk. It failed on the real pristine source:

```text
patch failed: src/evdev.c:774
```

A synthetic source reconstructed from the patch accepted it because it reproduced the same malformed context.

Rule:

> Never claim exact-source applicability based only on a reconstructed preimage.

### Helper-name namespace collision

A custom helper named `normalized_length()` collided with an existing libinput helper of the same name and a different signature.

Rule:

> Prefix new internal helpers (`evdev_trackpoint_scroll_*`, etc.) and run the full compiler, not just patch checks.

---

## 40. Execution-path diagnostics

When a patch appears installed but behavior is unchanged, verify each boundary rather than inferring from output:

```text
correct library loaded
    -> device routed into TrackPoint button-scroll path
    -> raw report enters grid feed
    -> 2 ms timer ticks
    -> nonzero accelerated delta
    -> public continuous-axis event
```

Useful system checks:

```bash
which libinput
libinput --version
pkg-config --modversion libinput
ldconfig -p | grep libinput
ldd "$(command -v libinput)" | grep libinput
```

Useful device checks:

```bash
udevadm info --query=property --name=/dev/input/eventN |
  grep -E '^ID_INPUT_(MOUSE|POINTINGSTICK)='

gsettings get org.gnome.desktop.peripherals.pointingstick accel-profile
gsettings get org.gnome.desktop.peripherals.pointingstick speed
```

A temporary diagnostic build previously logged markers at routing, feed, tick, post-scroll input, and public notification. That instrumentation successfully distinguished a routing/configuration failure from an algorithm failure and should be recreated if future rebases become ambiguous.

Do not tune profile parameters until the actual active code path is proven.

---

# Part IX: Verification checklist

## 41. After applying but before installing

```bash
git rev-parse HEAD
git status --short
git diff --check
git diff --stat
ninja -C builddir
```

Confirm the commit is pinned and only the expected three files are modified.

---

## 42. After installing the library

```bash
sudo ldconfig
ldconfig -p | grep 'libinput\.so'
ldd "$(command -v libinput)" | grep libinput
```

Log out and back in, then inspect GNOME Shell's mappings if needed:

```bash
grep -F libinput "/proc/$(pgrep -n gnome-shell)/maps" | sort -u
```

---

## 43. After installing the udev rule

```bash
sudo udevadm test /sys/class/input/eventN 2>&1 |
  grep -E 'POINTINGSTICK|99-xy-3dg12-pointing-stick'

sudo udevadm control --reload-rules
```

Replug, then:

```bash
udevadm info --query=property --name=/dev/input/eventN |
  grep -E '^ID_INPUT_(MOUSE|POINTINGSTICK)='
```

---

## 44. After changing the config

Replug the adapter, then inspect behavior in Papers first.

The file currently expected is:

```bash
sudo sed -n '1,260p' /etc/libinput/trackpoint-scroll.conf
```

Check the active profile, startup controls, and tuned parameters:

```bash
grep -E '^(profile|clamp_negative_output|suppress_middle_click|first_step_|idle_reset_ms|hyperbolic_[auk])=' \
  /etc/libinput/trackpoint-scroll.conf
```

Expected current values:

```text
profile=hyperbolic
clamp_negative_output=false
suppress_middle_click=true
first_step_distance=0.4
first_step_axis_merge_ms=70.0
first_step_max_reports=-1
idle_reset_ms=333.3
hyperbolic_a=0.75
hyperbolic_u=1.6
hyperbolic_k=-1.175
```

## 45. Behavioral checks

With Scroll Lock custom toggle initially off:

1. Hold middle and move diagonally: verify immediate free two-dimensional
   scrolling.
2. Hold middle, then press Shift: verify mode changes to locked scrolling.
3. Release Shift and middle: verify the Shift release does not leak as an
   unmatched application event.
4. Press Scroll Lock once: verify the key/LED still behaves normally.
5. Start a new middle gesture: verify locked mode is now default.
6. Press Shift after middle: verify free mode is now selected for that gesture.
7. Press Scroll Lock again: verify the initial default returns.
8. With `suppress_middle_click=true`, tap middle without scrolling: verify no
   middle-click action or paste reaches the application.
9. Temporarily set `suppress_middle_click=false`, restart/re-add the device, and
   verify the same tap restores the ordinary middle-button click; then restore
   the tested `true` value.
10. Release after scrolling: verify prompt stop with no long momentum tail.
11. After more than 333.3 ms of raw-motion silence, issue `(0,1)`: verify one
    vertical fixed step of `first_step_distance`.
12. Issue `(0,2)` as the first report: verify it produces the same fixed vertical
    distance as `(0,1)`.
13. Within 70 ms, issue `(1,0)` then `(0,1)`: verify cumulative startup output
    equals `(distance,distance)`.
14. Within 70 ms, issue `(1,0)` then `(-1,0)`: verify the reversal is ignored as
    rebound.
15. Sustain force beyond startup: verify later reports transition to the
    selected profile without a startup pause.

Then inspect cursor settings separately:

```bash
gsettings get org.gnome.desktop.peripherals.pointingstick accel-profile
gsettings get org.gnome.desktop.peripherals.pointingstick speed
```

Finally check Firefox's saved multipliers in `about:config`.

# Part X: Maintenance, rollback, and future work

## 46. Distribution upgrades

The patch targets exactly libinput 1.31.0 commit:

```text
659967488e1e66d7fb7210c6b86860c8e1e5bed4
```

Do not assume it applies to a later libinput release merely because the version is close.

After an OS/libinput update:

- verify which `libinput.so.10` the dynamic linker selects;
- verify GNOME Shell's mapped library;
- verify the udev rule remains present;
- verify GSettings and Firefox preferences;
- rebuild/rebase the patch only against the new exact source.

A package upgrade normally does not overwrite `/usr/local`, but it can change ABI expectations, loader selection, or surrounding source sufficiently to require a rebase.

---

## 47. Rollback

To stop using the custom configuration while keeping the patched library:

```bash
sudo rm /etc/libinput/trackpoint-scroll.conf
```

The compiled default profile then applies after device/session restart.

Because v14 compiles middle-click suppression on by default, removing the file does not restore middle clicks. To restore only the click fallback, keep the file and set:

```ini
suppress_middle_click=false
```

Then re-add the TrackPoint or restart the session.

To remove the special device classification:

```bash
sudo rm /etc/udev/rules.d/99-xy-3dg12-pointing-stick.rules
sudo udevadm control --reload-rules
```

Then unplug/replug or reboot.

To uninstall the `/usr/local` build, from the original build tree try:

```bash
sudo ninja -C builddir uninstall
sudo ldconfig
```

If the uninstall target is unavailable, inspect:

```text
builddir/meson-logs/install-log.txt
```

and remove only the files installed by this build. Do not remove distribution-owned files under `/usr` indiscriminately.

Log out and back in after changing the installed library.

---

## 48. Known limitations of v14

- The config file is global rather than per-device.
- Settings are read only at device initialization; there is no live reload.
- The mode toggle and Shift target use process-wide static state.
- Only one active TrackPoint Shift target is represented.
- The consumed-Shift table has 16 fixed slots.
- The startup merge window is heuristic and tied to observed hardware behavior.
- Rebound suppression assumes opposite-sign components within the merge window
  are mechanical rebound; unusually fast deliberate reversals can be discarded.
- With `first_step_max_reports=-1`, every qualifying report inside the merge
  window can participate, although each axis still receives at most one fixed
  component.
- The first sustained profile report may use the 240 ms initial interval
  estimate when no measured sustained interval exists yet.
- Releasing the middle button cancels any remaining boxcar tail, so
  reconstructed pre-acceleration displacement is not conserved across early
  release.
- The profile input is a reconstructed 2 ms displacement sample, not a
  calibrated physical velocity unit.
- Application toolkits may scale continuous scroll deltas differently.
- The patch changes an internal implementation, not libinput's public API;
  Mutter/GNOME have no dedicated UI for these scroll-profile parameters.
- `suppress_middle_click` governs only the configured physical middle scroll
  button on the custom TrackPoint path; disabling that path restores ordinary
  libinput button handling.

## 49. Sensible future directions

Potential future improvements, only if testing justifies them:

1. Make the config path/device matching per-device rather than global.
2. Add a safe live-reload mechanism.
3. Move the dedicated accelerator into a cleaner internal filter module rather than keeping it in `evdev.c`.
4. Add libinput unit tests for boxcar conservation, ring wraparound, mode switching, and config parsing.
5. Add controlled tests for multiple simultaneous TrackPoints/keyboards.
6. Measure stopping-tail perception versus the 240 ms first interval.
7. Revisit a hardware-rebound filter only with reproducible raw evidence.
8. Package the patched library as a local Debian package instead of installing manually.

Avoid returning to mutable trajectory prediction, long smoothing time constants, or retrospective position correction unless a new design establishes a strict, testable invariant that prevents reverse repayment and hidden momentum.

---

# Appendix A: Complete current example configuration

```ini
# /etc/libinput/trackpoint-scroll.conf
# Read once when each TrackPoint is initialized.

profile=hyperbolic
clamp_negative_output=false
suppress_middle_click=true

first_step_distance=0.4
first_step_axis_merge_ms=70.0
first_step_max_reports=-1
idle_reset_ms=333.3

# Affine: y = k*x + b; y=1 at x=2.5
affine_k=0.4
affine_b=0.0

# Quadratic: y = a*(x-h)^2 + k; y=1.025 at x=2.5
quadratic_a=0.16
quadratic_h=0.0
quadratic_k=0.025

# Dedicated upstream adaptive filter; approximately y=1 at x=2.5 for M=1
adaptive_velocity_scale=100.0
adaptive_sensitivity=1.086
adaptive_speed=0.0

# Hyperbolic: y = a*sqrt(u^2 + x^2) + k; y≈1.051 at x=2.5
hyperbolic_a=0.75
hyperbolic_u=1.6
hyperbolic_k=-1.175
```

---

# Appendix B: One-pass installation command sequence

Adjust the patch/config source directory before running:

```bash
set -euo pipefail

PATCH_DIR="$HOME/Downloads"
PATCH="$PATCH_DIR/libinput-1.31.0-trackpoint-scroll-2ms-grid-startup-coalescing-middle-suppression-v14.patch"
CONF="$PATCH_DIR/trackpoint-scroll-v14.conf.example"
COMMIT=659967488e1e66d7fb7210c6b86860c8e1e5bed4

sudo apt update
sudo apt install git meson ninja-build build-essential pkg-config
sudo apt build-dep libinput

git clone https://gitlab.freedesktop.org/libinput/libinput.git \
  "$HOME/src/libinput-trackpoint-v14"
cd "$HOME/src/libinput-trackpoint-v14"
git checkout --detach "$COMMIT"
test "$(git rev-parse HEAD)" = "$COMMIT"

git apply --check "$PATCH"
git apply "$PATCH"
git diff --check

meson setup builddir \
  --prefix=/usr/local \
  --buildtype=release \
  -Dlibwacom=false \
  -Dtests=false \
  -Ddebug-gui=false \
  -Ddocumentation=false

ninja -C builddir
sudo ninja -C builddir install
sudo ldconfig

sudo install -D -m 0644 "$CONF" \
  /etc/libinput/trackpoint-scroll.conf

printf '%s\n' \
  'Library and config installed.' \
  'Install/verify the udev pointing-stick rule, then log out and back in.'
```

Do not blindly rerun this over an existing clone with uncommitted work. Use `git status` and preserve any work first.

---

## Build-source note

At the pinned commit, `meson_options.txt` declares `libwacom` as a boolean whose
default is `true`, described as tablet identification support. The build
recommendation above deliberately sets it to false for this TrackPoint-only
installation. The practical dependency problem was reported in the comments of
the Reddit investigation that originally documented the middle-button timeout.

Sources:

- [Pinned libinput `meson_options.txt`](https://github.com/external-mirrors/libinput/blob/659967488e1e66d7fb7210c6b86860c8e1e5bed4/meson_options.txt)
- [Reddit investigation and build follow-up](https://www.reddit.com/r/thinkpad/comments/1pgpygu/linux_libinput_may_be_sabotaging_your_middle/)

---

# Appendix C: Minimal environment snapshot for support

When reporting a problem, collect:

```bash
printf '%s\n' '== source =='
git rev-parse HEAD
git status --short
git diff --stat

printf '%s\n' '== installed libinput =='
which libinput
libinput --version
pkg-config --modversion libinput
ldd "$(command -v libinput)" | grep libinput
ldconfig -p | grep libinput

printf '%s\n' '== device classification =='
udevadm info --query=property --name=/dev/input/eventN |
  grep -E '^(ID_BUS|ID_VENDOR_ID|ID_MODEL_ID|ID_INPUT_)='

printf '%s\n' '== GNOME pointing-stick settings =='
gsettings list-recursively org.gnome.desktop.peripherals.pointingstick

printf '%s\n' '== scroll config =='
sudo cat /etc/libinput/trackpoint-scroll.conf
```

Also record:

- whether the test used Papers, Firefox, or `libinput debug-events`;
- Firefox's `mousewheel.default.delta_multiplier_x/y/z` values;
- Scroll Lock custom-toggle state;
- whether Shift was pressed before or after middle;
- whether the device was replugged after config changes;
- whether the GNOME session was restarted after installing a new library.

